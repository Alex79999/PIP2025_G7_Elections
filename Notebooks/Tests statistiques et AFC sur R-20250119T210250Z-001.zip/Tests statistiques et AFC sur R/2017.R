# Charger les bibliothèques
library(FactoMineR)
library(factoextra)

data_2017 <- read.csv('data_2017.csv')

# Création d'un tableau de contingence
tableau_contingence_2017 <- table(data_2017$Classe, data_2017$Classe.Parti)

# Affichage du tableau
print(tableau_contingence_2017)

# Appliquer fisher.test avec une simulation
fisher_test_2017 <- fisher.test(tableau_contingence_2017) 
print(fisher_test_2017)

# Réaliser l’AFC
afc_result_2017 <- CA(tableau_contingence_2017, graph = FALSE)

# Graphique des lignes et colonnes (modalités des deux variables)
fviz_ca_biplot(afc_result_2017, repel = TRUE, title = 'AFC 2017')

fviz_cos2(afc_result_2017, choice ="row", axes = 1:2, title = 'Cos2 des classes du taux de chômage 2017')
fviz_cos2(afc_result_2017, choice ="col", axes = 1:2, title = 'Cos2 des classes politiques 2017')

fviz_ca_row(afc_result_2017, col.row = "cos2", 
            gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
            title = 'Cos2 des classes du taux de chômage 2017',
            repel = TRUE)
fviz_ca_col(afc_result_2017, col.col = "cos2", 
            gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
            title = 'Cos2 des classes politiques 2017',
            repel = TRUE)

fviz_ca_biplot(afc_result_2017, 
               repel = TRUE, 
               col.row = "cos2", 
               col.col = "cos2", 
               gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
               title = "Cos2 des classes du taux de chômage et classes politiques (2017)")
