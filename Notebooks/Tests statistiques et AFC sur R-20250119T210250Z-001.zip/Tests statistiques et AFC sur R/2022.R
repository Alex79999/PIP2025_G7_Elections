# Charger les bibliothèques
library(FactoMineR)
library(factoextra)

data_2022 <- read.csv('data_2022.csv')

# Création d'un tableau de contingence
tableau_contingence_2022 <- table(data_2022$Classe, data_2022$Classe.Parti)

# Affichage du tableau
print(tableau_contingence_2022)


# Appliquer fisher.test avec une simulation
fisher_test_2022 <- fisher.test(tableau_contingence_2022, simulate.p.value = TRUE, B = 1e6) # B = nombre de permutations

print(fisher_test_2022)

# Réaliser l’AFC
afc_result_2022 <- CA(tableau_contingence_2022, graph = FALSE)

# Graphique des lignes et colonnes (modalités des deux variables)
fviz_ca_biplot(afc_result_2022, repel = TRUE, title = 'AFC 2022')

fviz_cos2(afc_result_2022, choice ="row", axes = 1:2, title = 'Cos2 des classes du taux de chômage 2022')
fviz_cos2(afc_result_2022, choice ="col", axes = 1:2, title = 'Cos2 des classes politiques 2022')


fviz_ca_row(afc_result_2022, col.row = "cos2", 
            gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
            title = 'Cos2 des classes du taux de chômage 2022',
            repel = TRUE)
fviz_ca_col(afc_result_2022, col.col = "cos2", 
            gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
            title = 'Cos2 des classes politiques 2022',
            repel = TRUE)

fviz_ca_biplot(afc_result_2022, 
               repel = TRUE, 
               col.row = "cos2", 
               col.col = "cos2", 
               gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
               title = "Cos2 des classes du taux de chômage et classes politiques (2022)")
